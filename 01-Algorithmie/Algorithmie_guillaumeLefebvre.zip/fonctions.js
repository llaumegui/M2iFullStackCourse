function perimeter(width,height){
    return (2*(width+height));
}

function biggestNumber(number1,number2){
    return Math.max(number1,number2);
}

// let perimeter1 = perimeter(5,10);
// let perimeter2 = perimeter(6,12);
// console.log(`Le plus grand périmètre est ${biggestNumber(perimeter1,perimeter2)}`);